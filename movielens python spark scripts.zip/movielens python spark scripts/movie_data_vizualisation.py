from pandas import *
import os
import matplotlib.pyplot as plt
from numpy import *
from scipy import misc

dir = "demo/pipeline-movielens-output/"
allfiles = os.listdir(dir)
allfiles = [file for file in allfiles if file.endswith('.json')]
print(allfiles)

df_list =[]
for folder in allfiles:
    dir_temp = dir+folder
    
    files = os.listdir(dir_temp)
    
    file = [file for file in files if file.endswith('.json')]
    print(file)
    path_temp = dir_temp+"/"+file[0]
    print(path_temp)
    
    df_temp = read_json(path_temp , lines=True)
    df_list.append(df_temp)


data_user_rating = df_list[0]

data_movie_rating = df_list[1]
data_movie_rating["realease_date"] = to_datetime(data_movie_rating["realease_date"])









def func(df , discrimination_column , summarize_column1 , summarize_column2 , summarize_column3):
    discrimination_elements = list(set(list(df[discrimination_column])))
    liste_discrimined_df = []
    for element in discrimination_elements:
        new_df = df[df[discrimination_column] == element]
        
        summarize_elements = list(set(list(new_df[summarize_column1])))
        
        for elt in summarize_elements:
            
            new_new_df = new_df[new_df[summarize_column1] == elt]
            aggregate_summarize1 = sum(list(new_new_df[summarize_column2]))
            aggregate_summarize2 = sum(list(new_new_df[summarize_column3]))/len(list(new_new_df[summarize_column3]))
            
            liste_discrimined_df.append([element , elt , aggregate_summarize1 , round(aggregate_summarize2,3)])
 
    return liste_discrimined_df


#sortir un barplot en fonction de l occupation des users qui notent le plus de films 
#faire un profil utilisateur (genre , occupation , nombre de films notés)
#ceux qui notent le mieux les films (average rating)

reslt = func(data_user_rating , "gender" , "occupation" , "ratingcount" , "avgrating")
#reslt2 = func(data_user_rating , "decade" , "occupation" , "ratingcount" , "avgrating")

df = DataFrame(reslt)

#print(df)
df.columns = ["gender" , "job" , "ratingcount" , "avgrating"]
df_man = df[df["gender"] == "M"]
df_woman = df[df["gender"] == "F"]

df_man = df_man.sort_values("ratingcount" , ascending = False)
df_woman = df_woman.sort_values("ratingcount" , ascending = False)

df_man.set_index("job" , inplace=True)
df_woman.set_index("job" , inplace=True)

df_man = df_man[["ratingcount" , "avgrating"]]
df_woman = df_woman[["ratingcount" , "avgrating"]]

print(df_man.head())
print(df_woman.head())


fig , axes = plt.subplots(nrows=2, ncols=1, figsize=(20,22))

df_man[["ratingcount"]].plot(ax =axes[0] , kind="bar" , title = "count of ratings for men")
df_man[["avgrating"]].plot(ax =axes[1] , kind="bar" , title = "average of ratings for men" , color = "orange")

fig.savefig("demo/pipeline-movielens-output/figures/rating_average_count_men.png")

fig , axes = plt.subplots(nrows=2, ncols=1, figsize=(20,22))

df_woman[["ratingcount"]].plot(ax =axes[0] , kind="bar" , title = "count of ratings for women")
df_woman[["avgrating"]].plot(ax =axes[1] , kind="bar" , title = "count of ratings for women" , color = "orange")

fig.savefig("demo/pipeline-movielens-output/figures/rating_average_count_women.png")

#films mieux notés par décennie (si possible)

decades = list(map(lambda x : int(((x.year%100)/10)) * 10 , list(data_movie_rating["realease_date"])))

data_movie_rating["decade"] = decades

cols = data_movie_rating.columns.tolist()
cols = cols[-1:] + cols[:-1]

data_movie_rating = data_movie_rating[cols]


discriminated_decades = list(set(data_movie_rating["decade"]))
decade_avg_rating = []
for decade in discriminated_decades:
    list_avg_rating =[]
    df = data_movie_rating[data_movie_rating["decade"] == decade]
    list_avg_rating = list(df["avgrating"])
    max_avg_movie = max(list_avg_rating)
    index_max_avg_movie = list_avg_rating.index(max_avg_movie)
    decade_avg_rating.append(list(df.iloc[index_max_avg_movie]))
    
high_avgrating_decade = DataFrame(decade_avg_rating)
high_avgrating_decade.columns = cols
high_avgrating_decade = high_avgrating_decade.sort_values("decade")
print(high_avgrating_decade)

















    
    


