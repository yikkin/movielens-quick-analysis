from pyspark.sql import SparkSession 
from pyspark.sql import SQLContext
from pyspark.sql.types import *



if __name__ == '__main__':
    scSpark = SparkSession \
        .builder \
        .appName("reading movielens files") \
        .getOrCreate()



path_users = "hive_data/demo_schneider/users"
path_ratings = "hive_data/demo_schneider/data"
path_items = "hive_data/demo_schneider/items"



#schema table
schema_ratings = StructType([
             StructField("user_id" , IntegerType(), True),
             StructField("movie_id", IntegerType(), True),
             StructField("rating", IntegerType(), True),
             StructField("timestamp", StringType(), True)
             ])

sep_ratings = "\t"

schema_users = StructType([
             StructField("user_id" , IntegerType(), True),
             StructField("age", IntegerType(), True),
             StructField("gender", StringType(), True),
             StructField("occupation", StringType(), True),
             StructField("zip_code", IntegerType(), True)
             ])

sep_users = "|"

schema_items = StructType([
             StructField("movie_id" , IntegerType(), True),
             StructField("title", StringType(), True),
             StructField("realease_date", StringType(), True),
             StructField("video_realease", StringType(), True),
             StructField("imdb", StringType(), True)
          
             ])

sep_items = "|"

#table movie_users
sdfData = scSpark.read.csv(path_users, schema=schema_users , header=False, sep=sep_users).cache()
#sdfData.printSchema()
sdfData.registerTempTable("movie_users")


#table ratings
sdfData2 = scSpark.read.csv(path_ratings, schema=schema_ratings , header=False, sep=sep_ratings).cache()
#sdfData2.printSchema()
sdfData2.registerTempTable("ratings")


#table movie_items
sdfData3 = scSpark.read.csv(path_items, schema=schema_items , header=False, sep=sep_items).cache()
#sdfData.printSchema()
sdfData3.registerTempTable("movie_items")

#queties




print("========movie with the highest average rating due to popularity======")

output = scSpark.sql("select n.movie_id , n.title , n.realease_date , ratingcount , avgrating  from (select movie_id , round(avg(rating),3) as avgrating , count(movie_id) as ratingcount from ratings group by movie_id order by avgrating desc) t join movie_items n on t.movie_id = n.movie_id where ratingcount > 10")
output.show(5)

output.coalesce(1).write.format('json').save('hive_data/demo_schneider/pipeline-movielens/high_rate_popularity.json')
print("writing movie data in json file done!")

print("========users with the most rated movies and the average rated========")

output = scSpark.sql("select u.user_id , u.gender , u.age , u.occupation , ratingcount , avgrating from (select user_id , count(movie_id) as ratingcount , round(avg(rating) , 2) as avgrating from ratings group by user_id order by ratingcount desc) r join movie_users u on u.user_id = r.user_id where ratingcount > 10")
output.show(5)

output.coalesce(1).write.format('json').save('hive_data/demo_schneider/pipeline-movielens/user_rate_avg.json')
print("writing user data in json file done!")


