#!/bin/bash 

echo "cleaning output movielens pipeline python spark hdfs"

hadoop fs -rm hive_data/demo_schneider/pipeline-movielens/high_rate_popularity.json/_*
hadoop fs -rm hive_data/demo_schneider/pipeline-movielens/user_rate_avg.json/_*

hadoop fs -rm hive_data/demo_schneider/pipeline-movielens/high_rate_popularity.json/part*
hadoop fs -rm hive_data/demo_schneider/pipeline-movielens/user_rate_avg.json/part*

hadoop fs -rmdir hive_data/demo_schneider/pipeline-movielens/high_rate_popularity.json
hadoop fs -rmdir hive_data/demo_schneider/pipeline-movielens/user_rate_avg.json

echo "cleaning output movielens pipeline hdfs done!"

hadoop fs -ls hive_data/demo_schneider/pipeline-movielens

rm demo/pipeline-movielens-output/high_rate_popularity.json/_*
rm demo/pipeline-movielens-output/user_rate_avg.json/_*

rm demo/pipeline-movielens-output/high_rate_popularity.json/part*
rm demo/pipeline-movielens-output/user_rate_avg.json/part*

rmdir demo/pipeline-movielens-output/high_rate_popularity.json
rmdir demo/pipeline-movielens-output/user_rate_avg.json

rm demo/pipeline-movielens-output/figures/rating_average_count_men.png
rm demo/pipeline-movielens-output/figures/rating_average_count_women.png
echo "cleaning out output movielens pipeline locally done!"

