#!/bin/bash 

#clearing of the screen
clear 
#versioning of spark framework
export SPARK_MAJOR_VERSION=2

echo "Extraction , Transformation and Loading of data (movie_users , movie_items and ratings)"

spark-submit demo/spark-pipeline-movielens.py

echo "verification loading json files in hdfs"

hadoop fs -ls hive_data/demo_schneider/pipeline-movielens

echo "files completed!"

hadoop fs -get hive_data/demo_schneider/pipeline-movielens/high_rate_popularity.json demo/pipeline-movielens-output
hadoop fs -get hive_data/demo_schneider/pipeline-movielens/user_rate_avg.json demo/pipeline-movielens-output

echo "files imported locally done!"

ls demo/pipeline-movielens-output/high_rate_popularity.json 
ls demo/pipeline-movielens-output/user_rate_avg.json

echo "files importation checked!"

python3 demo/movie_data_vizualisation.py

echo "figures located in demo/pipeline-movielens-output/figures"
ls demo/pipeline-movielens-output/figures

echo "THX FOR YOUR ATTENTION!!"
